﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Spot1 = New System.Windows.Forms.Label()
        Me.Spot2 = New System.Windows.Forms.Label()
        Me.Spot3 = New System.Windows.Forms.Label()
        Me.Div1 = New System.Windows.Forms.Label()
        Me.Div2 = New System.Windows.Forms.Label()
        Me.Div3 = New System.Windows.Forms.Label()
        Me.Spot4 = New System.Windows.Forms.Label()
        Me.Div4 = New System.Windows.Forms.Label()
        Me.Spot5 = New System.Windows.Forms.Label()
        Me.Spot6 = New System.Windows.Forms.Label()
        Me.Spot7 = New System.Windows.Forms.Label()
        Me.Spot8 = New System.Windows.Forms.Label()
        Me.Spot9 = New System.Windows.Forms.Label()
        Me.lblgameName = New System.Windows.Forms.Label()
        Me.lblXwins = New System.Windows.Forms.Label()
        Me.lblOwins = New System.Windows.Forms.Label()
        Me.lblTies = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Spot1
        '
        Me.Spot1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot1.Location = New System.Drawing.Point(49, 70)
        Me.Spot1.Name = "Spot1"
        Me.Spot1.Size = New System.Drawing.Size(84, 84)
        Me.Spot1.TabIndex = 0
        Me.Spot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Spot2
        '
        Me.Spot2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot2.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot2.Location = New System.Drawing.Point(154, 70)
        Me.Spot2.Name = "Spot2"
        Me.Spot2.Size = New System.Drawing.Size(84, 84)
        Me.Spot2.TabIndex = 1
        Me.Spot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Spot3
        '
        Me.Spot3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot3.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot3.Location = New System.Drawing.Point(259, 70)
        Me.Spot3.Name = "Spot3"
        Me.Spot3.Size = New System.Drawing.Size(84, 84)
        Me.Spot3.TabIndex = 2
        Me.Spot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Div1
        '
        Me.Div1.BackColor = System.Drawing.Color.Black
        Me.Div1.Location = New System.Drawing.Point(138, 70)
        Me.Div1.Name = "Div1"
        Me.Div1.Size = New System.Drawing.Size(10, 273)
        Me.Div1.TabIndex = 3
        '
        'Div2
        '
        Me.Div2.BackColor = System.Drawing.Color.Black
        Me.Div2.Location = New System.Drawing.Point(244, 70)
        Me.Div2.Name = "Div2"
        Me.Div2.Size = New System.Drawing.Size(10, 273)
        Me.Div2.TabIndex = 4
        '
        'Div3
        '
        Me.Div3.BackColor = System.Drawing.Color.Black
        Me.Div3.Location = New System.Drawing.Point(46, 154)
        Me.Div3.Name = "Div3"
        Me.Div3.Size = New System.Drawing.Size(297, 10)
        Me.Div3.TabIndex = 5
        '
        'Spot4
        '
        Me.Spot4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot4.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot4.Location = New System.Drawing.Point(49, 164)
        Me.Spot4.Name = "Spot4"
        Me.Spot4.Size = New System.Drawing.Size(84, 84)
        Me.Spot4.TabIndex = 6
        Me.Spot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Div4
        '
        Me.Div4.BackColor = System.Drawing.Color.Black
        Me.Div4.Location = New System.Drawing.Point(46, 248)
        Me.Div4.Name = "Div4"
        Me.Div4.Size = New System.Drawing.Size(297, 10)
        Me.Div4.TabIndex = 7
        '
        'Spot5
        '
        Me.Spot5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot5.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot5.Location = New System.Drawing.Point(154, 164)
        Me.Spot5.Name = "Spot5"
        Me.Spot5.Size = New System.Drawing.Size(84, 84)
        Me.Spot5.TabIndex = 8
        Me.Spot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Spot6
        '
        Me.Spot6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot6.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot6.Location = New System.Drawing.Point(259, 164)
        Me.Spot6.Name = "Spot6"
        Me.Spot6.Size = New System.Drawing.Size(84, 84)
        Me.Spot6.TabIndex = 9
        Me.Spot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Spot7
        '
        Me.Spot7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot7.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot7.Location = New System.Drawing.Point(49, 258)
        Me.Spot7.Name = "Spot7"
        Me.Spot7.Size = New System.Drawing.Size(84, 84)
        Me.Spot7.TabIndex = 10
        Me.Spot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Spot8
        '
        Me.Spot8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot8.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot8.Location = New System.Drawing.Point(154, 258)
        Me.Spot8.Name = "Spot8"
        Me.Spot8.Size = New System.Drawing.Size(84, 84)
        Me.Spot8.TabIndex = 11
        Me.Spot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Spot9
        '
        Me.Spot9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Spot9.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Spot9.Location = New System.Drawing.Point(260, 258)
        Me.Spot9.Name = "Spot9"
        Me.Spot9.Size = New System.Drawing.Size(84, 84)
        Me.Spot9.TabIndex = 12
        Me.Spot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblgameName
        '
        Me.lblgameName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblgameName.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgameName.Location = New System.Drawing.Point(118, 11)
        Me.lblgameName.Name = "lblgameName"
        Me.lblgameName.Size = New System.Drawing.Size(155, 45)
        Me.lblgameName.TabIndex = 13
        Me.lblgameName.Text = "Tic-Tac-Toe"
        Me.lblgameName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblXwins
        '
        Me.lblXwins.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblXwins.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXwins.Location = New System.Drawing.Point(34, 365)
        Me.lblXwins.Name = "lblXwins"
        Me.lblXwins.Size = New System.Drawing.Size(99, 26)
        Me.lblXwins.TabIndex = 14
        Me.lblXwins.Text = "X Wins: 0"
        Me.lblXwins.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOwins
        '
        Me.lblOwins.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOwins.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOwins.Location = New System.Drawing.Point(141, 365)
        Me.lblOwins.Name = "lblOwins"
        Me.lblOwins.Size = New System.Drawing.Size(99, 26)
        Me.lblOwins.TabIndex = 15
        Me.lblOwins.Text = "O Wins: 0"
        Me.lblOwins.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTies
        '
        Me.lblTies.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTies.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTies.Location = New System.Drawing.Point(259, 365)
        Me.lblTies.Name = "lblTies"
        Me.lblTies.Size = New System.Drawing.Size(99, 26)
        Me.lblTies.TabIndex = 16
        Me.lblTies.Text = "Ties: 0"
        Me.lblTies.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Moccasin
        Me.ClientSize = New System.Drawing.Size(389, 442)
        Me.Controls.Add(Me.lblTies)
        Me.Controls.Add(Me.lblOwins)
        Me.Controls.Add(Me.lblXwins)
        Me.Controls.Add(Me.lblgameName)
        Me.Controls.Add(Me.Spot9)
        Me.Controls.Add(Me.Spot8)
        Me.Controls.Add(Me.Spot7)
        Me.Controls.Add(Me.Spot6)
        Me.Controls.Add(Me.Spot5)
        Me.Controls.Add(Me.Div4)
        Me.Controls.Add(Me.Spot4)
        Me.Controls.Add(Me.Div3)
        Me.Controls.Add(Me.Div2)
        Me.Controls.Add(Me.Div1)
        Me.Controls.Add(Me.Spot3)
        Me.Controls.Add(Me.Spot2)
        Me.Controls.Add(Me.Spot1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Spot1 As Label
    Friend WithEvents Spot2 As Label
    Friend WithEvents Spot3 As Label
    Friend WithEvents Div1 As Label
    Friend WithEvents Div2 As Label
    Friend WithEvents Div3 As Label
    Friend WithEvents Spot4 As Label
    Friend WithEvents Div4 As Label
    Friend WithEvents Spot5 As Label
    Friend WithEvents Spot6 As Label
    Friend WithEvents Spot7 As Label
    Friend WithEvents Spot8 As Label
    Friend WithEvents Spot9 As Label
    Friend WithEvents lblgameName As Label
    Friend WithEvents lblXwins As Label
    Friend WithEvents lblOwins As Label
    Friend WithEvents lblTies As Label
End Class
