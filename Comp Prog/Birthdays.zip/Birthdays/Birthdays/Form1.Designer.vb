﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBday = New System.Windows.Forms.Label()
        Me.btnJan = New System.Windows.Forms.Button()
        Me.btnFeb = New System.Windows.Forms.Button()
        Me.btnMar = New System.Windows.Forms.Button()
        Me.btnApr = New System.Windows.Forms.Button()
        Me.btnMay = New System.Windows.Forms.Button()
        Me.btnJun = New System.Windows.Forms.Button()
        Me.btnDec = New System.Windows.Forms.Button()
        Me.btnNov = New System.Windows.Forms.Button()
        Me.btnOct = New System.Windows.Forms.Button()
        Me.btnSept = New System.Windows.Forms.Button()
        Me.btnAug = New System.Windows.Forms.Button()
        Me.btnJul = New System.Windows.Forms.Button()
        Me.lblPpl = New System.Windows.Forms.Label()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblBday
        '
        Me.lblBday.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBday.Font = New System.Drawing.Font("Perpetua Titling MT", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBday.Location = New System.Drawing.Point(305, 9)
        Me.lblBday.Name = "lblBday"
        Me.lblBday.Size = New System.Drawing.Size(208, 56)
        Me.lblBday.TabIndex = 0
        Me.lblBday.Text = "Birthdays"
        Me.lblBday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnJan
        '
        Me.btnJan.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnJan.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnJan.Location = New System.Drawing.Point(12, 119)
        Me.btnJan.Name = "btnJan"
        Me.btnJan.Size = New System.Drawing.Size(124, 39)
        Me.btnJan.TabIndex = 1
        Me.btnJan.Text = "January"
        Me.btnJan.UseVisualStyleBackColor = False
        '
        'btnFeb
        '
        Me.btnFeb.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFeb.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFeb.Location = New System.Drawing.Point(12, 164)
        Me.btnFeb.Name = "btnFeb"
        Me.btnFeb.Size = New System.Drawing.Size(124, 39)
        Me.btnFeb.TabIndex = 2
        Me.btnFeb.Text = "February"
        Me.btnFeb.UseVisualStyleBackColor = False
        '
        'btnMar
        '
        Me.btnMar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnMar.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMar.Location = New System.Drawing.Point(12, 209)
        Me.btnMar.Name = "btnMar"
        Me.btnMar.Size = New System.Drawing.Size(124, 39)
        Me.btnMar.TabIndex = 3
        Me.btnMar.Text = "March"
        Me.btnMar.UseVisualStyleBackColor = False
        '
        'btnApr
        '
        Me.btnApr.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnApr.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnApr.Location = New System.Drawing.Point(12, 254)
        Me.btnApr.Name = "btnApr"
        Me.btnApr.Size = New System.Drawing.Size(124, 39)
        Me.btnApr.TabIndex = 4
        Me.btnApr.Text = "April"
        Me.btnApr.UseVisualStyleBackColor = False
        '
        'btnMay
        '
        Me.btnMay.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnMay.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMay.Location = New System.Drawing.Point(12, 299)
        Me.btnMay.Name = "btnMay"
        Me.btnMay.Size = New System.Drawing.Size(124, 39)
        Me.btnMay.TabIndex = 5
        Me.btnMay.Text = "May"
        Me.btnMay.UseVisualStyleBackColor = False
        '
        'btnJun
        '
        Me.btnJun.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnJun.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnJun.Location = New System.Drawing.Point(12, 344)
        Me.btnJun.Name = "btnJun"
        Me.btnJun.Size = New System.Drawing.Size(124, 39)
        Me.btnJun.TabIndex = 6
        Me.btnJun.Text = "June"
        Me.btnJun.UseVisualStyleBackColor = False
        '
        'btnDec
        '
        Me.btnDec.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnDec.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDec.Location = New System.Drawing.Point(681, 344)
        Me.btnDec.Name = "btnDec"
        Me.btnDec.Size = New System.Drawing.Size(124, 39)
        Me.btnDec.TabIndex = 12
        Me.btnDec.Text = "December"
        Me.btnDec.UseVisualStyleBackColor = False
        '
        'btnNov
        '
        Me.btnNov.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnNov.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNov.Location = New System.Drawing.Point(681, 299)
        Me.btnNov.Name = "btnNov"
        Me.btnNov.Size = New System.Drawing.Size(124, 39)
        Me.btnNov.TabIndex = 11
        Me.btnNov.Text = "November"
        Me.btnNov.UseVisualStyleBackColor = False
        '
        'btnOct
        '
        Me.btnOct.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnOct.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOct.Location = New System.Drawing.Point(681, 254)
        Me.btnOct.Name = "btnOct"
        Me.btnOct.Size = New System.Drawing.Size(124, 39)
        Me.btnOct.TabIndex = 10
        Me.btnOct.Text = "October"
        Me.btnOct.UseVisualStyleBackColor = False
        '
        'btnSept
        '
        Me.btnSept.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnSept.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSept.Location = New System.Drawing.Point(681, 209)
        Me.btnSept.Name = "btnSept"
        Me.btnSept.Size = New System.Drawing.Size(124, 39)
        Me.btnSept.TabIndex = 9
        Me.btnSept.Text = "September"
        Me.btnSept.UseVisualStyleBackColor = False
        '
        'btnAug
        '
        Me.btnAug.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnAug.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAug.Location = New System.Drawing.Point(681, 164)
        Me.btnAug.Name = "btnAug"
        Me.btnAug.Size = New System.Drawing.Size(124, 39)
        Me.btnAug.TabIndex = 8
        Me.btnAug.Text = "August"
        Me.btnAug.UseVisualStyleBackColor = False
        '
        'btnJul
        '
        Me.btnJul.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnJul.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnJul.Location = New System.Drawing.Point(681, 119)
        Me.btnJul.Name = "btnJul"
        Me.btnJul.Size = New System.Drawing.Size(124, 39)
        Me.btnJul.TabIndex = 7
        Me.btnJul.Text = "July"
        Me.btnJul.UseVisualStyleBackColor = False
        '
        'lblPpl
        '
        Me.lblPpl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPpl.Font = New System.Drawing.Font("Perpetua Titling MT", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPpl.Location = New System.Drawing.Point(305, 445)
        Me.lblPpl.Name = "lblPpl"
        Me.lblPpl.Size = New System.Drawing.Size(208, 38)
        Me.lblPpl.TabIndex = 13
        Me.lblPpl.Text = "Person"
        Me.lblPpl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDOB
        '
        Me.lblDOB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDOB.Font = New System.Drawing.Font("Perpetua Titling MT", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDOB.Location = New System.Drawing.Point(305, 483)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(208, 38)
        Me.lblDOB.TabIndex = 14
        Me.lblDOB.Text = "D.O.B."
        Me.lblDOB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(142, 68)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(533, 374)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(817, 530)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblDOB)
        Me.Controls.Add(Me.lblPpl)
        Me.Controls.Add(Me.btnDec)
        Me.Controls.Add(Me.btnNov)
        Me.Controls.Add(Me.btnOct)
        Me.Controls.Add(Me.btnSept)
        Me.Controls.Add(Me.btnAug)
        Me.Controls.Add(Me.btnJul)
        Me.Controls.Add(Me.btnJun)
        Me.Controls.Add(Me.btnMay)
        Me.Controls.Add(Me.btnApr)
        Me.Controls.Add(Me.btnMar)
        Me.Controls.Add(Me.btnFeb)
        Me.Controls.Add(Me.btnJan)
        Me.Controls.Add(Me.lblBday)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblBday As Label
    Friend WithEvents btnJan As Button
    Friend WithEvents btnFeb As Button
    Friend WithEvents btnMar As Button
    Friend WithEvents btnApr As Button
    Friend WithEvents btnMay As Button
    Friend WithEvents btnJun As Button
    Friend WithEvents btnDec As Button
    Friend WithEvents btnNov As Button
    Friend WithEvents btnOct As Button
    Friend WithEvents btnSept As Button
    Friend WithEvents btnAug As Button
    Friend WithEvents btnJul As Button
    Friend WithEvents lblPpl As Label
    Friend WithEvents lblDOB As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
