﻿Public Class Form1
    'JANUARY
    Private Sub btnJan_Click(sender As Object, e As EventArgs) Handles btnJan.Click
        PictureBox1.Image = Image.FromFile("keiichi.png")
        lblPpl.Text = "Keiichi Tsuchiya"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "January 30th, 1956"
        lblDOB.Font = New Font("Perpetua Titling MT", 12, FontStyle.Regular)
    End Sub
    'FEBRUARY
    Private Sub btnFeb_Click(sender As Object, e As EventArgs) Handles btnFeb.Click
        PictureBox1.Image = Image.FromFile("chunkz.png")
        lblPpl.Text = "Aj Shabeel"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "February 21st, 1996"
        lblDOB.Font = New Font("Perpetua Titling MT", 12, FontStyle.Regular)
    End Sub
    'MARCH
    Private Sub btnMar_Click(sender As Object, e As EventArgs) Handles btnMar.Click
        PictureBox1.Image = Image.FromFile("seuss.png")
        lblPpl.Text = "Theodor Geisel"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "March 2nd, 1904"
        lblDOB.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
    End Sub
    'APRIL
    Private Sub btnApr_Click(sender As Object, e As EventArgs) Handles btnApr.Click
        PictureBox1.Image = Image.FromFile("chris.png")
        lblPpl.Text = "Chris Forsberg"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "April 6th, 1982"
        lblDOB.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
    End Sub
    'MAY
    Private Sub btnMay_Click(sender As Object, e As EventArgs) Handles btnMay.Click
        PictureBox1.Image = Image.FromFile("adamv2.png")
        lblPpl.Text = "Adam Lizotte-Zeisler"
        lblPpl.Font = New Font("Perpetua Titling MT", 12, FontStyle.Regular)
        lblDOB.Text = "May 5th, 1995"
        lblDOB.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
    End Sub
    'JUNE
    Private Sub btnJun_Click(sender As Object, e As EventArgs) Handles btnJun.Click
        PictureBox1.Image = Image.FromFile("notchv2.png")
        lblPpl.Text = "Markus Perrson"
        lblPpl.Font = New Font("Perpetua Titling MT", 14, FontStyle.Regular)
        lblDOB.Text = "June 1st, 1979"
        lblDOB.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
    End Sub
    'JULY
    Private Sub btnJul_Click(sender As Object, e As EventArgs) Handles btnJul.Click
        PictureBox1.Image = Image.FromFile("dobrik.png")
        lblPpl.Text = "David Dobrik"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "July 23rd, 1996"
        lblDOB.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
    End Sub
    'AUGUST
    Private Sub btnAug_Click(sender As Object, e As EventArgs) Handles btnAug.Click
        PictureBox1.Image = Image.FromFile("mj.png")
        lblPpl.Text = "Michael Jackson"
        lblPpl.Font = New Font("Perpetua Titling MT", 14, FontStyle.Regular)
        lblDOB.Text = "August 29th, 1958"
        lblDOB.Font = New Font("Perpetua Titling MT", 12, FontStyle.Regular)
    End Sub
    'SEPTEMBER
    Private Sub btnSept_Click(sender As Object, e As EventArgs) Handles btnSept.Click
        PictureBox1.Image = Image.FromFile("maxv3.png")
        lblPpl.Text = "Max Verstappen"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "September 30th, 1997"
        lblDOB.Font = New Font("Perpetua Titling MT", 12, FontStyle.Regular)
    End Sub
    'OCTOBER
    Private Sub btnOct_Click(sender As Object, e As EventArgs) Handles btnOct.Click
        PictureBox1.Image = Image.FromFile("pewdss.png")
        lblPpl.Text = "Felix Kjellberg"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "October 24th, 1989"
        lblDOB.Font = New Font("Perpetua Titling MT", 14, FontStyle.Regular)
    End Sub
    'NOVEMBER
    Private Sub btnNov_Click(sender As Object, e As EventArgs) Handles btnNov.Click
        PictureBox1.Image = Image.FromFile("bruce.png")
        lblPpl.Text = "Bruce Lee"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "November 27th, 1940"
        lblDOB.Font = New Font("Perpetua Titling MT", 12, FontStyle.Regular)
    End Sub
    'DECEMBER
    Private Sub btnDec_Click(sender As Object, e As EventArgs) Handles btnDec.Click
        PictureBox1.Image = Image.FromFile("kai.png")
        lblPpl.Text = "Kai Cenat III"
        lblPpl.Font = New Font("Perpetua Titling MT", 16, FontStyle.Regular)
        lblDOB.Text = "December 16, 2001"
        lblDOB.Font = New Font("Perpetua Titling MT", 14, FontStyle.Regular)
    End Sub
End Class
