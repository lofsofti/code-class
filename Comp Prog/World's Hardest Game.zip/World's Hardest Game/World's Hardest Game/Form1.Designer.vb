﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Wall1 = New System.Windows.Forms.Label()
        Me.Wall2 = New System.Windows.Forms.Label()
        Me.Wall3 = New System.Windows.Forms.Label()
        Me.Wall4 = New System.Windows.Forms.Label()
        Me.Wall5 = New System.Windows.Forms.Label()
        Me.Wall6 = New System.Windows.Forms.Label()
        Me.Wall7 = New System.Windows.Forms.Label()
        Me.Wall8 = New System.Windows.Forms.Label()
        Me.Wall9 = New System.Windows.Forms.Label()
        Me.Wall10 = New System.Windows.Forms.Label()
        Me.Wall11 = New System.Windows.Forms.Label()
        Me.Wall12 = New System.Windows.Forms.Label()
        Me.Wall13 = New System.Windows.Forms.Label()
        Me.Wall14 = New System.Windows.Forms.Label()
        Me.Wall15 = New System.Windows.Forms.Label()
        Me.Wall16 = New System.Windows.Forms.Label()
        Me.Ball1 = New System.Windows.Forms.Label()
        Me.Ball3 = New System.Windows.Forms.Label()
        Me.Ball2 = New System.Windows.Forms.Label()
        Me.Ball4 = New System.Windows.Forms.Label()
        Me.GreenStart = New System.Windows.Forms.Label()
        Me.GreenEnd = New System.Windows.Forms.Label()
        Me.LevelLabel = New System.Windows.Forms.Label()
        Me.MenuLabel = New System.Windows.Forms.Label()
        Me.DeathsLabel = New System.Windows.Forms.Label()
        Me.Box = New System.Windows.Forms.Label()
        Me.boxTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ballTimer = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Wall1
        '
        Me.Wall1.BackColor = System.Drawing.Color.Black
        Me.Wall1.Location = New System.Drawing.Point(37, 117)
        Me.Wall1.Name = "Wall1"
        Me.Wall1.Size = New System.Drawing.Size(66, 3)
        Me.Wall1.TabIndex = 0
        '
        'Wall2
        '
        Me.Wall2.BackColor = System.Drawing.Color.Black
        Me.Wall2.Location = New System.Drawing.Point(100, 120)
        Me.Wall2.Name = "Wall2"
        Me.Wall2.Size = New System.Drawing.Size(3, 100)
        Me.Wall2.TabIndex = 1
        '
        'Wall3
        '
        Me.Wall3.BackColor = System.Drawing.Color.Black
        Me.Wall3.Location = New System.Drawing.Point(100, 217)
        Me.Wall3.Name = "Wall3"
        Me.Wall3.Size = New System.Drawing.Size(20, 3)
        Me.Wall3.TabIndex = 2
        '
        'Wall4
        '
        Me.Wall4.BackColor = System.Drawing.Color.Black
        Me.Wall4.Location = New System.Drawing.Point(117, 140)
        Me.Wall4.Name = "Wall4"
        Me.Wall4.Size = New System.Drawing.Size(3, 80)
        Me.Wall4.TabIndex = 3
        '
        'Wall5
        '
        Me.Wall5.BackColor = System.Drawing.Color.Black
        Me.Wall5.Location = New System.Drawing.Point(117, 137)
        Me.Wall5.Name = "Wall5"
        Me.Wall5.Size = New System.Drawing.Size(183, 3)
        Me.Wall5.TabIndex = 4
        '
        'Wall6
        '
        Me.Wall6.BackColor = System.Drawing.Color.Black
        Me.Wall6.Location = New System.Drawing.Point(297, 120)
        Me.Wall6.Name = "Wall6"
        Me.Wall6.Size = New System.Drawing.Size(3, 20)
        Me.Wall6.TabIndex = 5
        '
        'Wall7
        '
        Me.Wall7.BackColor = System.Drawing.Color.Black
        Me.Wall7.Location = New System.Drawing.Point(297, 117)
        Me.Wall7.Name = "Wall7"
        Me.Wall7.Size = New System.Drawing.Size(106, 3)
        Me.Wall7.TabIndex = 6
        '
        'Wall8
        '
        Me.Wall8.BackColor = System.Drawing.Color.Black
        Me.Wall8.Location = New System.Drawing.Point(400, 120)
        Me.Wall8.Name = "Wall8"
        Me.Wall8.Size = New System.Drawing.Size(3, 120)
        Me.Wall8.TabIndex = 7
        '
        'Wall9
        '
        Me.Wall9.BackColor = System.Drawing.Color.Black
        Me.Wall9.Location = New System.Drawing.Point(337, 240)
        Me.Wall9.Name = "Wall9"
        Me.Wall9.Size = New System.Drawing.Size(66, 3)
        Me.Wall9.TabIndex = 8
        '
        'Wall10
        '
        Me.Wall10.BackColor = System.Drawing.Color.Black
        Me.Wall10.Location = New System.Drawing.Point(337, 140)
        Me.Wall10.Name = "Wall10"
        Me.Wall10.Size = New System.Drawing.Size(3, 100)
        Me.Wall10.TabIndex = 9
        '
        'Wall11
        '
        Me.Wall11.BackColor = System.Drawing.Color.Black
        Me.Wall11.Location = New System.Drawing.Point(320, 140)
        Me.Wall11.Name = "Wall11"
        Me.Wall11.Size = New System.Drawing.Size(20, 3)
        Me.Wall11.TabIndex = 10
        '
        'Wall12
        '
        Me.Wall12.BackColor = System.Drawing.Color.Black
        Me.Wall12.Location = New System.Drawing.Point(320, 140)
        Me.Wall12.Name = "Wall12"
        Me.Wall12.Size = New System.Drawing.Size(3, 80)
        Me.Wall12.TabIndex = 11
        '
        'Wall13
        '
        Me.Wall13.BackColor = System.Drawing.Color.Black
        Me.Wall13.Location = New System.Drawing.Point(140, 220)
        Me.Wall13.Name = "Wall13"
        Me.Wall13.Size = New System.Drawing.Size(183, 3)
        Me.Wall13.TabIndex = 12
        '
        'Wall14
        '
        Me.Wall14.BackColor = System.Drawing.Color.Black
        Me.Wall14.Location = New System.Drawing.Point(140, 220)
        Me.Wall14.Name = "Wall14"
        Me.Wall14.Size = New System.Drawing.Size(3, 20)
        Me.Wall14.TabIndex = 13
        '
        'Wall15
        '
        Me.Wall15.BackColor = System.Drawing.Color.Black
        Me.Wall15.Location = New System.Drawing.Point(37, 240)
        Me.Wall15.Name = "Wall15"
        Me.Wall15.Size = New System.Drawing.Size(106, 3)
        Me.Wall15.TabIndex = 14
        '
        'Wall16
        '
        Me.Wall16.BackColor = System.Drawing.Color.Black
        Me.Wall16.Location = New System.Drawing.Point(37, 120)
        Me.Wall16.Name = "Wall16"
        Me.Wall16.Size = New System.Drawing.Size(3, 120)
        Me.Wall16.TabIndex = 15
        '
        'Ball1
        '
        Me.Ball1.BackColor = System.Drawing.Color.Blue
        Me.Ball1.Location = New System.Drawing.Point(308, 144)
        Me.Ball1.Name = "Ball1"
        Me.Ball1.Size = New System.Drawing.Size(12, 12)
        Me.Ball1.TabIndex = 16
        '
        'Ball3
        '
        Me.Ball3.BackColor = System.Drawing.Color.Blue
        Me.Ball3.Location = New System.Drawing.Point(308, 184)
        Me.Ball3.Name = "Ball3"
        Me.Ball3.Size = New System.Drawing.Size(12, 12)
        Me.Ball3.TabIndex = 17
        '
        'Ball2
        '
        Me.Ball2.BackColor = System.Drawing.Color.Blue
        Me.Ball2.Location = New System.Drawing.Point(120, 164)
        Me.Ball2.Name = "Ball2"
        Me.Ball2.Size = New System.Drawing.Size(12, 12)
        Me.Ball2.TabIndex = 18
        '
        'Ball4
        '
        Me.Ball4.BackColor = System.Drawing.Color.Blue
        Me.Ball4.Location = New System.Drawing.Point(120, 204)
        Me.Ball4.Name = "Ball4"
        Me.Ball4.Size = New System.Drawing.Size(12, 12)
        Me.Ball4.TabIndex = 19
        '
        'GreenStart
        '
        Me.GreenStart.BackColor = System.Drawing.Color.PaleGreen
        Me.GreenStart.Location = New System.Drawing.Point(40, 120)
        Me.GreenStart.Name = "GreenStart"
        Me.GreenStart.Size = New System.Drawing.Size(60, 120)
        Me.GreenStart.TabIndex = 20
        '
        'GreenEnd
        '
        Me.GreenEnd.BackColor = System.Drawing.Color.PaleGreen
        Me.GreenEnd.Location = New System.Drawing.Point(340, 120)
        Me.GreenEnd.Name = "GreenEnd"
        Me.GreenEnd.Size = New System.Drawing.Size(60, 120)
        Me.GreenEnd.TabIndex = 21
        '
        'LevelLabel
        '
        Me.LevelLabel.BackColor = System.Drawing.Color.Black
        Me.LevelLabel.ForeColor = System.Drawing.Color.White
        Me.LevelLabel.Location = New System.Drawing.Point(140, 0)
        Me.LevelLabel.Name = "LevelLabel"
        Me.LevelLabel.Size = New System.Drawing.Size(160, 20)
        Me.LevelLabel.TabIndex = 22
        Me.LevelLabel.Text = "1/30"
        Me.LevelLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MenuLabel
        '
        Me.MenuLabel.BackColor = System.Drawing.Color.Black
        Me.MenuLabel.ForeColor = System.Drawing.Color.White
        Me.MenuLabel.Location = New System.Drawing.Point(0, 0)
        Me.MenuLabel.Name = "MenuLabel"
        Me.MenuLabel.Size = New System.Drawing.Size(140, 20)
        Me.MenuLabel.TabIndex = 23
        Me.MenuLabel.Text = "Menu"
        Me.MenuLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DeathsLabel
        '
        Me.DeathsLabel.BackColor = System.Drawing.Color.Black
        Me.DeathsLabel.ForeColor = System.Drawing.Color.White
        Me.DeathsLabel.Location = New System.Drawing.Point(300, 0)
        Me.DeathsLabel.Name = "DeathsLabel"
        Me.DeathsLabel.Size = New System.Drawing.Size(140, 20)
        Me.DeathsLabel.TabIndex = 24
        Me.DeathsLabel.Text = "Deaths: 0"
        Me.DeathsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Box
        '
        Me.Box.BackColor = System.Drawing.Color.Black
        Me.Box.Location = New System.Drawing.Point(62, 172)
        Me.Box.Name = "Box"
        Me.Box.Size = New System.Drawing.Size(16, 16)
        Me.Box.TabIndex = 25
        '
        'boxTimer
        '
        Me.boxTimer.Enabled = True
        Me.boxTimer.Interval = 16
        '
        'ballTimer
        '
        Me.ballTimer.Enabled = True
        Me.ballTimer.Interval = 60
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(443, 340)
        Me.Controls.Add(Me.Box)
        Me.Controls.Add(Me.DeathsLabel)
        Me.Controls.Add(Me.MenuLabel)
        Me.Controls.Add(Me.LevelLabel)
        Me.Controls.Add(Me.Ball4)
        Me.Controls.Add(Me.Ball2)
        Me.Controls.Add(Me.Ball3)
        Me.Controls.Add(Me.Ball1)
        Me.Controls.Add(Me.Wall16)
        Me.Controls.Add(Me.Wall15)
        Me.Controls.Add(Me.Wall14)
        Me.Controls.Add(Me.Wall13)
        Me.Controls.Add(Me.Wall12)
        Me.Controls.Add(Me.Wall11)
        Me.Controls.Add(Me.Wall10)
        Me.Controls.Add(Me.Wall9)
        Me.Controls.Add(Me.Wall8)
        Me.Controls.Add(Me.Wall7)
        Me.Controls.Add(Me.Wall6)
        Me.Controls.Add(Me.Wall5)
        Me.Controls.Add(Me.Wall4)
        Me.Controls.Add(Me.Wall3)
        Me.Controls.Add(Me.Wall2)
        Me.Controls.Add(Me.Wall1)
        Me.Controls.Add(Me.GreenStart)
        Me.Controls.Add(Me.GreenEnd)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Wall1 As Label
    Friend WithEvents Wall2 As Label
    Friend WithEvents Wall3 As Label
    Friend WithEvents Wall4 As Label
    Friend WithEvents Wall5 As Label
    Friend WithEvents Wall6 As Label
    Friend WithEvents Wall7 As Label
    Friend WithEvents Wall8 As Label
    Friend WithEvents Wall9 As Label
    Friend WithEvents Wall10 As Label
    Friend WithEvents Wall11 As Label
    Friend WithEvents Wall12 As Label
    Friend WithEvents Wall13 As Label
    Friend WithEvents Wall14 As Label
    Friend WithEvents Wall15 As Label
    Friend WithEvents Wall16 As Label
    Friend WithEvents Ball1 As Label
    Friend WithEvents Ball3 As Label
    Friend WithEvents Ball2 As Label
    Friend WithEvents Ball4 As Label
    Friend WithEvents GreenStart As Label
    Friend WithEvents GreenEnd As Label
    Friend WithEvents LevelLabel As Label
    Friend WithEvents MenuLabel As Label
    Friend WithEvents DeathsLabel As Label
    Friend WithEvents Box As Label
    Friend WithEvents boxTimer As Timer
    Friend WithEvents ballTimer As Timer
End Class
