﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Coral
        Me.Label1.Location = New System.Drawing.Point(-1, -1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(801, 20)
        Me.Label1.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Coral
        Me.Label2.Location = New System.Drawing.Point(-1, 430)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(801, 20)
        Me.Label2.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Coral
        Me.Label3.Location = New System.Drawing.Point(0, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(22, 395)
        Me.Label3.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Coral
        Me.Label4.Location = New System.Drawing.Point(779, -1)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 451)
        Me.Label4.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Coral
        Me.Label5.Location = New System.Drawing.Point(693, 352)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 20)
        Me.Label5.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Coral
        Me.Label6.Location = New System.Drawing.Point(674, 352)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(20, 98)
        Me.Label6.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Coral
        Me.Label7.Location = New System.Drawing.Point(760, 352)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 20)
        Me.Label7.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Coral
        Me.Label8.Location = New System.Drawing.Point(575, 286)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(119, 20)
        Me.Label8.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Coral
        Me.Label9.Location = New System.Drawing.Point(575, 306)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 66)
        Me.Label9.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Coral
        Me.Label10.Location = New System.Drawing.Point(384, 352)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(213, 20)
        Me.Label10.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Coral
        Me.Label11.Location = New System.Drawing.Point(97, 352)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(213, 20)
        Me.Label11.TabIndex = 10
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Coral
        Me.Label12.Location = New System.Drawing.Point(204, 352)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(20, 98)
        Me.Label12.TabIndex = 11
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Coral
        Me.Label13.Location = New System.Drawing.Point(240, 286)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(213, 20)
        Me.Label13.TabIndex = 12
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Coral
        Me.Label14.Location = New System.Drawing.Point(86, 55)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(213, 20)
        Me.Label14.TabIndex = 13
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Coral
        Me.Label15.Location = New System.Drawing.Point(86, 75)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(22, 152)
        Me.Label15.TabIndex = 14
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Coral
        Me.Label16.Location = New System.Drawing.Point(368, 55)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(213, 20)
        Me.Label16.TabIndex = 15
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Coral
        Me.Label17.Location = New System.Drawing.Point(199, 128)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(243, 20)
        Me.Label17.TabIndex = 16
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.Coral
        Me.Label18.Location = New System.Drawing.Point(181, 128)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(22, 99)
        Me.Label18.TabIndex = 17
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Coral
        Me.Label19.Location = New System.Drawing.Point(86, 207)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(117, 20)
        Me.Label19.TabIndex = 18
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Coral
        Me.Label20.Location = New System.Drawing.Point(157, 273)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(22, 99)
        Me.Label20.TabIndex = 19
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Coral
        Me.Label21.Location = New System.Drawing.Point(508, 128)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(213, 20)
        Me.Label21.TabIndex = 20
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Coral
        Me.Label22.Location = New System.Drawing.Point(508, 148)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(22, 158)
        Me.Label22.TabIndex = 21
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Coral
        Me.Label23.Location = New System.Drawing.Point(587, 207)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(213, 20)
        Me.Label23.TabIndex = 22
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Coral
        Me.Label24.Location = New System.Drawing.Point(559, 55)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(22, 93)
        Me.Label24.TabIndex = 23
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Coral
        Me.Label25.Location = New System.Drawing.Point(329, 139)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(22, 158)
        Me.Label25.TabIndex = 24
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Coral
        Me.Label26.Location = New System.Drawing.Point(402, 207)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(114, 20)
        Me.Label26.TabIndex = 25
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.SystemColors.Control
        Me.Label27.Location = New System.Drawing.Point(441, 129)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(67, 20)
        Me.Label27.TabIndex = 26
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.SystemColors.Control
        Me.Label28.Location = New System.Drawing.Point(157, 227)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(22, 46)
        Me.Label28.TabIndex = 27
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.SystemColors.Control
        Me.Label29.Location = New System.Drawing.Point(693, 286)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(85, 20)
        Me.Label29.TabIndex = 28
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.Cyan
        Me.Label30.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label30.Location = New System.Drawing.Point(716, 385)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(44, 34)
        Me.Label30.TabIndex = 29
        Me.Label30.Text = "End"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
End Class
