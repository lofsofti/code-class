﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Private Sub Label30_Click(sender As Object, e As EventArgs) Handles Label30.Click
        MsgBox("You finished!")
    End Sub

    Private Sub Label1_MouseEnter(sender As Object, e As EventArgs) Handles Label1.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label2_MouseEnter(sender As Object, e As EventArgs) Handles Label2.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label3_MouseEnter(sender As Object, e As EventArgs) Handles Label3.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label4_MouseEnter(sender As Object, e As EventArgs) Handles Label4.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label5_MouseEnter(sender As Object, e As EventArgs) Handles Label5.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label6_MouseEnter(sender As Object, e As EventArgs) Handles Label6.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label7_MouseEnter(sender As Object, e As EventArgs) Handles Label7.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label8_MouseEnter(sender As Object, e As EventArgs) Handles Label8.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label9_MouseEnter(sender As Object, e As EventArgs) Handles Label9.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label10_MouseEnter(sender As Object, e As EventArgs) Handles Label10.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label11_MouseEnter(sender As Object, e As EventArgs) Handles Label11.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label12_MouseEnter(sender As Object, e As EventArgs) Handles Label12.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label13_MouseEnter(sender As Object, e As EventArgs) Handles Label13.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label14_MouseEnter(sender As Object, e As EventArgs) Handles Label14.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label15_MouseEnter(sender As Object, e As EventArgs) Handles Label15.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label16_MouseEnter(sender As Object, e As EventArgs) Handles Label16.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label17_MouseEnter(sender As Object, e As EventArgs) Handles Label17.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label18_MouseEnter(sender As Object, e As EventArgs) Handles Label18.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label19_MouseEnter(sender As Object, e As EventArgs) Handles Label19.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label20_MouseEnter(sender As Object, e As EventArgs) Handles Label20.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label21_MouseEnter(sender As Object, e As EventArgs) Handles Label21.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label22_MouseEnter(sender As Object, e As EventArgs) Handles Label22.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label23_MouseEnter(sender As Object, e As EventArgs) Handles Label23.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label24_MouseEnter(sender As Object, e As EventArgs) Handles Label24.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label25_MouseEnter(sender As Object, e As EventArgs) Handles Label25.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label26_MouseEnter(sender As Object, e As EventArgs) Handles Label26.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label27_MouseEnter(sender As Object, e As EventArgs) Handles Label27.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label28_MouseEnter(sender As Object, e As EventArgs) Handles Label28.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Label29_MouseEnter(sender As Object, e As EventArgs) Handles Label29.MouseEnter
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
    Private Sub Form1_MouseClick(sender As Object, e As MouseEventArgs) Handles Me.MouseClick
        Windows.Forms.Cursor.Position = New Point(560, 344)
    End Sub
End Class
